# Javascript Game of Life
Conway's Game of Life in Javascript and canvas.

## Demo
Online at http://pmav.eu/stuff/javascript-game-of-life-v3.1.1/
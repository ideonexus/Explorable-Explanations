// Challenge proposed by Lu @HolixSF
// create a Taroko Gorge logger
// determine how many times a particular line is generated over a set period of time

// infinite haiku

// create a word bank
var one_syllable = []
var two_syllables = []
var three_syllables = []

// generate a line
  // 5 syllable line
  // 7 syllable line

// determine whether next line is 5 syllables, 7 syllables or a break

// set up a loop for generating lines
